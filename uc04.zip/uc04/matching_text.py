import pandas as pd
import os
import re
import string
#from nltk.corpus import stopwords
import nltk

"""
1) try to use fuzzy wyzzu lib
2) connect to sql?
3) very different desciprion
"""

#stopwords = set(stopwords.words('english'))

stemmer = nltk.PorterStemmer()
#regex = re.compile('[%s]' % re.escape(string.punctuation+"—”“’"+"0123456789"+"\n\r\/"))

regex = re.compile('[%s]' % re.escape(string.punctuation))

class text_analyzer:
    def __init__(self, df, desc_compare):
        self.df = df
        self.description_compare = desc_compare


    def combine_two_methods(self):
        self.__kmp_match()
        self.__metric()
        
    
    def __kmp_match(self):
        
        res = [None]*self.df.shape[0]
        for i in self.df.index:
            desc = self.df.loc[i, 'desc']

            words = self.description_compare.split()
            
            f = False
            for word in words:

                if len(word) < 3:
                    continue
                
                if KMPSearch(word, desc) == 1: # pat, txt
                    f = True
                    break
            if f:
                res[i] = 1
     
        self.df['further_go'] = res
        return
        
    def __metric(self):

        #print(self.df['further_go'])

        res = [float('inf')]*self.df.shape[0]
        
        
        for i in self.df.index:
            
            if self.df.loc[i,'further_go'] != 1:
                continue
                
            desc = self.df.loc[i, 'desc']
            metric = distance(self.description_compare,desc) 
            res[i] = metric

        self.df['metric'] = res
        return


    def merge_table(self,table,true_desc,true_desc_compare):

        new = pd.DataFrame({'description':true_desc,'description_from_sql':[true_desc_compare]*self.df.shape[0],'score':self.df['metric']})
        
        return pd.concat([table, new],ignore_index = True)
        
                 


def read_files(path): # generator
    
    file_list = os.listdir(path)
    res = []
    
    for filename in sorted(file_list): # sorted
        print(filename)
        p = path + '/' + filename

        current_file = pd.read_csv(p)

        yield current_file



def distance(a, b) -> int: # leven dist, a into b
    n, m = len(a), len(b)
    if n > m:
        a, b = b, a
        n, m = m, n
    current_row = range(n + 1)  
    for i in range(1, m + 1):
        previous_row, current_row = current_row, [i] + [0] * n
        for j in range(1, n + 1):
            add, delete, change = previous_row[j] + 1, current_row[j - 1] + 1, previous_row[j - 1]
            if a[j - 1] != b[i - 1]:
                change += 1
            current_row[j] = min(add, delete, change) 
    return current_row[n]




# Python program for KMP Algorithm
def KMPSearch(pat, txt) -> int:
    
    p = [0]*len(pat)
    j = 0
    i = 1

    while i < len(pat):
        if pat[j] == pat[i]:
            p[i] = j+1
            i += 1
            j += 1
        else:
            if j == 0:
                p[i] = 0;
                i += 1
            else:
                j = p[j-1]


    m = len(pat)
    n = len(txt)

    i = 0
    j = 0
    while i < n:
        if txt[i] == pat[j]:
            i += 1
            j += 1
            if j == m:
                return 1
        else:
            if j > 0:
                j = p[j-1]
            else:
                i += 1

    if i == n and j != m:
        return -1

    return None





def prepare_text(description:pd.Series, comp_description:str) -> list[list[str]]:
    
    description = description.apply(lambda x : regex.sub('', x))
    
    comp_description = regex.sub('', comp_description)

    description = description.str.lower()
    description = description.str.strip()

    comp_description = comp_description.lower()

    return description, comp_description






def main(path):

    i = 3
    
    files = read_files(path)

    res = pd.DataFrame([])

    for file in files:

        if i == 0:
            break
        
        po = list(set(file['po_number']))

        print(f"Here's a PO of this csv file: {po}\n")
        
        desc_compare = input("Enter the string to compare: ")

        c_desc_compare = desc_compare
        
        print()

        desc,desc_compare = prepare_text(file['description'],desc_compare)


        tmp_df = pd.DataFrame({'desc':desc})

        analyzer = text_analyzer(tmp_df,desc_compare)

        analyzer.combine_two_methods()

        res = analyzer.merge_table(res,file['description'],c_desc_compare)

        i -= 1

    res.to_excel("output.xlsx")  

        


main('desc match true')

#for word in "diesel b uls coloré".split():
#    print(word)
#    print(KMPSearch(word,'federal carbon'))
